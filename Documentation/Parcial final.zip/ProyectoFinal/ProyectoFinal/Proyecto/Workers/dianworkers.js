import { Client, Variables, logger } from "camunda-external-task-client-js";

const config = { baseUrl: "http://localhost:8080/engine-rest", use: logger };
const client = new Client(config);

client.subscribe("codeAssignment", async function({ task, taskService }) {
  // Asignar un código mediante la función codeAssignment
  const dianCode = codeAssignment();

  // Asignar valores a Customer_id y Customer_name
  const customerId = "1006856318";
  const customerName = "Leiner Mendoza";

  // Imprimir el código de la DIAN y asignar variables para la respuesta
  console.log(`Dian_Code${dianCode}`);
  const processVariables = new Variables();
  processVariables.set("dianCode", dianCode);
  processVariables.set("customerId", customerId);
  processVariables.set("customerName", customerName);

  // Concatenar customerId y customerName
  const customerOutput = `${customerId} - ${customerName}`;
  console.log(`DIANCode ${customerOutput}`);
  
  // Completar la tarea con las variables de respuesta
  await taskService.complete(task, processVariables);
});

// Función para asignar un código (anteriormente generateDianCode)
function codeAssignment() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
